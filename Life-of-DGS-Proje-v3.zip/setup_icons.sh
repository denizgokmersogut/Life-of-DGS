#!/bin/bash
mkdir -p android/app/src/main/res/drawable
mkdir -p android/app/src/main/res/mipmap-anydpi-v26

# 1. Pembe Logo (Kız Modu - Yıldız, Kalp ve Neon Pembe DGS)
cat << 'EOF' > android/app/src/main/res/drawable/ic_logo_pink.xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path android:fillColor="#1A0B12" android:pathData="M0,0h108v108h-108z"/>
    <path android:fillColor="#FF6B9E" android:pathData="M54,18 C73.88,18 90,34.12 90,54 C90,73.88 73.88,90 54,90 C34.12,90 18,73.88 18,54 C18,34.12 34.12,18 54,18 Z M54,23 C36.88,23 23,36.88 23,54 C23,71.12 36.88,85 54,85 C71.12,85 85,71.12 85,54 C85,36.88 71.12,23 54,23 Z"/>
    <path android:fillColor="#FF9EBB" android:pathData="M24,46 C42,26 68,26 84,46 C66,34 42,34 24,46 Z"/>
    <path android:fillColor="#FF9EBB" android:pathData="M84,62 C66,82 40,82 24,62 C42,74 66,74 84,62 Z"/>
    <path android:fillColor="#FF6B9E" android:pathData="M34,33 C32.5,31.5 30,32 30,34.5 C30,37 34,40 34,40 C34,40 38,37 38,34.5 C38,32 35.5,31.5 34,33 Z"/>
    <path android:fillColor="#FFFFFF" android:pathData="M74,30 L75.2,33.8 L79,35 L75.2,36.2 L74,40 L72.8,36.2 L69,35 L72.8,33.8 Z"/>
    <path android:fillColor="#FF9EBB" android:pathData="M32,70 L33,73 L36,74 L33,75 L32,78 L31,75 L28,74 L31,73 Z"/>
    <path android:fillColor="#FF6B9E" android:pathData="M32,44 L40,44 C46,44 49,47.5 49,54 C49,60.5 46,64 40,64 L32,64 Z M36.5,48 L36.5,60 L40,60 C43,60 44.5,58 44.5,54 C44.5,50 43,48 40,48 Z"/>
    <path android:fillColor="#FF6B9E" android:pathData="M58,43.5 C62,43.5 65,45.5 66,48.5 L61.5,50 C60.8,48.2 59.5,47.5 57.8,47.5 C54.8,47.5 53,50 53,54 C53,58 54.8,60.5 57.8,60.5 C60.5,60.5 61.8,59 61.8,56.5 L58,56.5 L58,53 L66,53 L66,64 L62.5,64 L62.5,61.5 C61,63.2 59,64.2 57,64.2 C51.8,64.2 48.5,60 48.5,54 C48.5,48 52.2,43.5 58,43.5 Z"/>
    <path android:fillColor="#FF6B9E" android:pathData="M73.5,43.5 C77.5,43.5 80.2,45.2 81,48.2 L76.8,49.8 C76.2,48 75.2,47.2 73.5,47.2 C71.8,47.2 70.8,48 70.8,49.4 C70.8,51 72.5,51.6 75.2,52.6 C79,54 81.2,55.8 81.2,59.5 C81.2,63.2 78.2,64.5 73.8,64.5 C69.8,64.5 67,62.5 66.2,59.2 L70.5,57.6 C71.2,59.8 72.4,60.8 74.2,60.8 C76.2,60.8 77.2,60 77.2,58.6 C77.2,57 75.5,56.4 72.8,55.4 C69,54 66.8,52.2 66.8,49 C66.8,45.5 69.5,43.5 73.5,43.5 Z"/>
</vector>
EOF

# 2. Turkuaz Logo (Erkek Modu - Yıldız Yörüngesi ve Neon Turkuaz DGS)
cat << 'EOF' > android/app/src/main/res/drawable/ic_logo_turquoise.xml
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path android:fillColor="#07191A" android:pathData="M0,0h108v108h-108z"/>
    <path android:fillColor="#00D2D3" android:pathData="M54,18 C73.88,18 90,34.12 90,54 C90,73.88 73.88,90 54,90 C34.12,90 18,73.88 18,54 C18,34.12 34.12,18 54,18 Z M54,23 C36.88,23 23,36.88 23,54 C23,71.12 36.88,85 54,85 C71.12,85 85,71.12 85,54 C85,36.88 71.12,23 54,23 Z"/>
    <path android:fillColor="#48DBFB" android:pathData="M24,46 C42,26 68,26 84,46 C66,34 42,34 24,46 Z"/>
    <path android:fillColor="#48DBFB" android:pathData="M84,62 C66,82 40,82 24,62 C42,74 66,74 84,62 Z"/>
    <path android:fillColor="#FFFFFF" android:pathData="M34,30 L35.2,33.8 L39,35 L35.2,36.2 L34,40 L32.8,36.2 L29,35 L32.8,33.8 Z"/>
    <path android:fillColor="#48DBFB" android:pathData="M74,69 L75.2,72.8 L79,74 L75.2,75.2 L74,79 L72.8,75.2 L69,74 L72.8,72.8 Z"/>
    <path android:fillColor="#00D2D3" android:pathData="M32,44 L40,44 C46,44 49,47.5 49,54 C49,60.5 46,64 40,64 L32,64 Z M36.5,48 L36.5,60 L40,60 C43,60 44.5,58 44.5,54 C44.5,50 43,48 40,48 Z"/>
    <path android:fillColor="#00D2D3" android:pathData="M58,43.5 C62,43.5 65,45.5 66,48.5 L61.5,50 C60.8,48.2 59.5,47.5 57.8,47.5 C54.8,47.5 53,50 53,54 C53,58 54.8,60.5 57.8,60.5 C60.5,60.5 61.8,59 61.8,56.5 L58,56.5 L58,53 L66,53 L66,64 L62.5,64 L62.5,61.5 C61,63.2 59,64.2 57,64.2 C51.8,64.2 48.5,60 48.5,54 C48.5,48 52.2,43.5 58,43.5 Z"/>
    <path android:fillColor="#00D2D3" android:pathData="M73.5,43.5 C77.5,43.5 80.2,45.2 81,48.2 L76.8,49.8 C76.2,48 75.2,47.2 73.5,47.2 C71.8,47.2 70.8,48 70.8,49.4 C70.8,51 72.5,51.6 75.2,52.6 C79,54 81.2,55.8 81.2,59.5 C81.2,63.2 78.2,64.5 73.8,64.5 C69.8,64.5 67,62.5 66.2,59.2 L70.5,57.6 C71.2,59.8 72.4,60.8 74.2,60.8 C76.2,60.8 77.2,60 77.2,58.6 C77.2,57 75.5,56.4 72.8,55.4 C69,54 66.8,52.2 66.8,49 C66.8,45.5 69.5,43.5 73.5,43.5 Z"/>
</vector>
EOF

cat << 'EOF' > android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_logo_turquoise"/>
    <foreground android:drawable="@drawable/ic_logo_turquoise"/>
</adaptive-icon>
EOF

cat << 'EOF' > android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_logo_turquoise"/>
    <foreground android:drawable="@drawable/ic_logo_turquoise"/>
</adaptive-icon>
EOF

cat << 'EOF' > android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_pink.xml
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_logo_pink"/>
    <foreground android:drawable="@drawable/ic_logo_pink"/>
</adaptive-icon>
EOF

# 3. AndroidManifest.xml içine Activity Alias ve Konum/Alarm izinlerini ekle
python3 - << 'PYEOF'
with open("android/app/src/main/AndroidManifest.xml", "r") as f:
    content = f.read()

perms = """    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.VIBRATE" />"""

if "ACCESS_FINE_LOCATION" not in content:
    content = content.replace("<application", perms + "
    <application")

aliases = """        <activity-alias
            android:name=".MainActivityBoy"
            android:enabled="true"
            android:exported="true"
            android:icon="@mipmap/ic_launcher"
            android:roundIcon="@mipmap/ic_launcher_round"
            android:label="Life of DGS"
            android:targetActivity=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity-alias>

        <activity-alias
            android:name=".MainActivityGirl"
            android:enabled="false"
            android:exported="true"
            android:icon="@mipmap/ic_launcher_pink"
            android:roundIcon="@mipmap/ic_launcher_pink"
            android:label="Life of DGS"
            android:targetActivity=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity-alias>"""

content = content.replace('<category android:name="android.intent.category.LAUNCHER" />', '')
content = content.replace('</application>', aliases + '
    </application>')

with open("android/app/src/main/AndroidManifest.xml", "w") as f:
    f.write(content)
PYEOF

# 4. MainActivity.java içine JS arayüzü (setIcon) ekle
MAIN_JAVA=$(find android/app/src/main/java -name "MainActivity.java" | head -n 1)
cat << 'EOF' > "$MAIN_JAVA"
package com.dgs.lifeofdgs;

import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.bridge.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void setIcon(String gender) {
                PackageManager pm = getPackageManager();
                ComponentName boyComp = new ComponentName(MainActivity.this, "com.dgs.lifeofdgs.MainActivityBoy");
                ComponentName girlComp = new ComponentName(MainActivity.this, "com.dgs.lifeofdgs.MainActivityGirl");
                if ("girl".equals(gender)) {
                    pm.setComponentEnabledSetting(girlComp, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
                    pm.setComponentEnabledSetting(boyComp, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
                } else {
                    pm.setComponentEnabledSetting(boyComp, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
                    pm.setComponentEnabledSetting(girlComp, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
                }
            }
        }, "AndroidIconBridge");
    }
}
EOF
